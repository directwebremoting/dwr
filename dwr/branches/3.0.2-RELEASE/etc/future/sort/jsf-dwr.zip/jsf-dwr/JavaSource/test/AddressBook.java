package test;

import java.util.ArrayList;

public class AddressBook {
	private ArrayList contacts = null;
	
	public AddressBook() {
		contacts = new ArrayList();
	}
	
	public Contact addContact(Contact contact) {
		contacts.add(contact);
		return contact;
	}
	
	public String removeContact(int index) {
		contacts.remove(index);
		return "" + index;
	}

	public ArrayList getContacts() {
		return contacts;
	}

	public void setContacts(ArrayList contacts) {
		this.contacts = contacts;
	}
}
