var contact = { name:null, surname:null, email:null };
var getName = function(contact) { return contact.name };
var getSurname = function(contact) { return contact.surname };
var getEmail = function(contact) { return contact.email };

//Callbacks
function fillTable(contacts)
{
    var theTable = $('myform:addressBook');
	var body = theTable.tBodies[0];
	
	while (body.childNodes.length > 0){
		body.removeChild(body.firstChild);
	}
	
    for(i = 0; i < contacts.length; i++) {
    	var contact = contacts[i];
    	var tr = document.createElement('tr');
		var td = document.createElement('td');
		td.appendChild(document.createTextNode(contact.name));
		tr.appendChild(td);

		td = document.createElement('td');
		td.appendChild(document.createTextNode(contact.surname));
		tr.appendChild(td);
		
		td = document.createElement('td');
		td.appendChild(document.createTextNode(contact.email));
		tr.appendChild(td);

		td = document.createElement('td');
		td.innerHTML = '<input type="button" value="Delete" onclick="removeContact('+i+',\''+contact.name+' ' + contact.surname +'\')"/>';
		tr.appendChild(td);

		theTable.tBodies[0].appendChild(tr);    
    }
}

function fillForm(data) {
	var tokens = data.tokenize(",", " ", true);
	var inputName = document.getElementById('myform2:name');
	var inputSurname = document.getElementById('myform2:surname');
	var inputEmail = document.getElementById('myform2:email');
	contact.name = tokens[0];
	contact.surname = tokens[1];
	contact.email = tokens[2];
	inputName.value = contact.name;
	inputSurname.value = contact.surname;
	inputEmail.value = contact.email;
};

function removeRow(index) {
    var theTable = $('myform:addressBook');
	var body = theTable.tBodies[0];
	
	var row = body.childNodes[index];
	if(row != null) {
		Effect.Fade(row);
		Effect.SlideUp(row.nextSibling);
		//body.removeChild(row);
	} else {
		alert('row is null');
	}
}

function addRow(contact) {
    var theTable = $('myform:addressBook');
	var body = theTable.tBodies[0];
	var tr = document.createElement('tr');
	var td = document.createElement('td');
	td.appendChild(document.createTextNode(contact.name));
	tr.appendChild(td);

	td = document.createElement('td');
	td.appendChild(document.createTextNode(contact.surname));
	tr.appendChild(td);
	
	td = document.createElement('td');
	td.appendChild(document.createTextNode(contact.email));
	tr.appendChild(td);

	td = document.createElement('td');
	td.innerHTML = '<input type="button" value="Delete" onclick="removeContact(' + (theTable.tBodies[0].childNodes.length) + ',\''+contact.name+' ' + contact.surname +'\')"/>';
	tr.appendChild(td);

	theTable.tBodies[0].appendChild(tr);
	Element.setInlineOpacity(tr, 0);
	new Effect.Appear(tr);
}

//End callbacks

function update()
{
    AddressBook.getContacts(fillTable);
}

function removeContact(index, name) {
    if (confirm("Are you sure you want to delete " + name + "?")) {	
    	AddressBook.removeContact(removeRow, index);
    }
}

function defaultContact() {
	Contact.toString(fillForm);
}

function addContact() {
	var inputName = document.getElementById('myform2:name');
	var inputSurname = document.getElementById('myform2:surname');
	var inputEmail = document.getElementById('myform2:email');
	contact.name = inputName.value;
	contact.surname = inputSurname.value;
	contact.email = inputEmail.value;
	AddressBook.addContact(addRow, contact);
}
