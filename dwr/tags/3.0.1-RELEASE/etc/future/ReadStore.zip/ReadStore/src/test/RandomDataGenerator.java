package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomDataGenerator implements DataGenerator {

    private Random generator = new Random();

    private String random() {
        return String.valueOf(Math.abs(generator.nextLong()));
    }

    public List<DataObject> getData() {
        List<DataObject> objects = new ArrayList<DataObject>(25);
        for (int i = 0; i < 25; i++) objects.add(new DataObject(random(), random(), random()));
        return objects;
    }

}
