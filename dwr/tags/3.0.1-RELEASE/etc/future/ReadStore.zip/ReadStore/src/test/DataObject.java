package test;

public class DataObject {

    private String identifier;
    private String value1;

    public DataObject(String a, String b, String c) {
        this.identifier = a;
        this.value1 = b;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getValue1() {
        return value1;
    }

    public void setValue1(String value1) {
        this.value1 = value1;
    }

}
