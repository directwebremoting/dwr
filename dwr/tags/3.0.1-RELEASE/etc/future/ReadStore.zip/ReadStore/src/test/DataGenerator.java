package test;

import java.util.List;

public interface DataGenerator {

    List<DataObject> getData();

}
