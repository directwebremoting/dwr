if(!dojo._hasResource["internna.data.DWRReadStore"]) {
    dojo._hasResource["internna.data.DWRReadStore"] = true;
    dojo.provide("internna.data.DWRReadStore");
    dojo.require("dojox.data.QueryReadStore");
    dojo.declare("internna.data.DWRReadStore", dojox.data.QueryReadStore, {
        jsFunction: void(null),
        _identifier: "identifier",
        fetch: function(request) {
            request = request || {};
            if(!request.store) request.store = this;
            if(!request.serverQuery) request.serverQuery = {};
            request.serverQuery.start = 0;
            if (request.count) request.serverQuery.count = request.count;
            request.serverQuery.callback = dojo.hitch(this, function(data) {this._callback(request, data)});
            this.jsFunction(request);
            return request;
        },
        _callback : function(request, data) {
            this._items = [];
            dojo.forEach(data, function(e){this._items.push({i:e, r:this});}, this);
            this._itemsByIdentity = {};
            dojo.forEach(data, function(e){this._itemsByIdentity[e[this._identifier]] = e;}, this);
            if (request.onComplete) request.onComplete(this._items, request);
        }
    });
}