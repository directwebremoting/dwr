Author: Rainier Ramos

Prereqs
=======
- Maven 1.0.2 (http://maven.apache.org/maven-1.x/start/download.html)

Recommended Environment
=======================
- JBossIDE: Provides XDoclet auto-completion
- Mevenide Eclipse Plugin: Allows execution of Maven goals from within Eclipse

Build and Deploy
================
1. Run 'maven' from the project root.  This executes the default goal (dev:build).
   The dwr.xml file will be generated in target/xdoclet/webdoclet/WEB-INF
2. Deploy the assembled war (target/dwr-xdoclet.war) in Tomcat.
3. Open http://localhost:8080/dwr-xdoclet in a browser.  The main page will redirect you to the DWR test page.
