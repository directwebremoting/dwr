package org.rakstar.dwr;

/**
 * @dwr.create
 *      javascript = "AnotherService"
 *
 * @author rakstar
 *
 */
public class Service2 {

    /**
     * @dwr.include
     * @return
     */
    public String testInclude() {
        return "Success! This method is on the white list!";
    }
    
    /**
     * @dwr.include
     * @return
     */
    public String testIncludeMeToo() {
        return "Success! This method is also on the white list!";
    }

    /**
     * @return
     */
    public String notIncluded1() {
        return "This should not be included.";
    }

    /**
     * @return
     */
    public String notIncluded2() {
        return "This too should not be included.";
    }

    
}
