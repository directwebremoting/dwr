package org.rakstar.dwr;

import java.util.Map;

import uk.ltd.getahead.dwr.Creator;

/**
 * @dwr.creator
 *      id = "testcreator"
 *
 * @author rakstar
 */
public class TestCreator implements Creator {

    public void setProperties(Map arg0) throws IllegalArgumentException {

    }

    public Class getType() {
        return null;
    }

    public Object getInstance() throws InstantiationException {
        return null;
    }

    public String getScope() {
        return null;
    }

}
