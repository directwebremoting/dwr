package org.rakstar.dwr;

import java.io.Serializable;

/**
 * @dwr.create
 *      javascript = "Service"
 *      scope = "session"
 *
 * @author rakstar
 */
public class Service implements Serializable {

    /**
     */
    private static final long serialVersionUID = 3042643872300389170L;

    /**
     * @param name
     * @return
     */
    public String getHello(final String name) {
        return "Hello " + name;
     }

    /**
     * @return
     */
    public User getUser(String name, int age) {

        User user = new User();
        user.setName(name);
        user.setAge(age);

        return user;
    }

    /**
     * @dwr.exclude
     * @return
     */
    public String testExclude() {
        return "This method should not be accessible!";
    }

    /**
     * @dwr.auth
     *      role = "admin"
     *
     * @dwr.auth
     *      role = "devel"
     *
     * @return
     */
    public String testRestricted() {
        return "Access to this method is restricted!";
    }
}
