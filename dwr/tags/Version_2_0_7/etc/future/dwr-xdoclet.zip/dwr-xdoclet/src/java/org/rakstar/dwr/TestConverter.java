package org.rakstar.dwr;

import uk.ltd.getahead.dwr.ConversionException;
import uk.ltd.getahead.dwr.Converter;
import uk.ltd.getahead.dwr.ConverterManager;
import uk.ltd.getahead.dwr.InboundContext;
import uk.ltd.getahead.dwr.InboundVariable;
import uk.ltd.getahead.dwr.OutboundContext;

/**
 * @dwr.converter
 *      id = "testconverter"
 *
 * @author rakstar
 */
public class TestConverter implements Converter {

    public void setConverterManager(ConverterManager arg0) {

    }

    public Object convertInbound(Class arg0, InboundVariable arg1,
            InboundContext arg2) throws ConversionException {
        return null;
    }

    public String convertOutbound(Object arg0, String arg1, OutboundContext arg2)
            throws ConversionException {
        return null;
    }

}
