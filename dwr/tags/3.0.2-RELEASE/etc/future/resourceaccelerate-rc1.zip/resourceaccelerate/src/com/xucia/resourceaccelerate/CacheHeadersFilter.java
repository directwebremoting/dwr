/**
 * Resource Accelerate
Copyright (C) 2007 Xucia Incorporation
Author - Kris Zyp - kriszyp@xucia.com
The contents of this file are subject to the Mozilla Public License Version
1.1 (the "License"); you may not use this file except in compliance with
the License. You may obtain a copy of the License at
http://www.mozilla.org/MPL/

Software distributed under the License is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
for the specific language governing rights and limitations under the
License.
 */

package com.xucia.resourceaccelerate;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
/**
 * 
 * @author Kris Zyp
 *With contributions from:
Arthur Blake
Hayden James
 *This filter adds a caching headers to the response, so that the browser does not
 *need to continually request a resource over and over. 
 */
public class CacheHeadersFilter implements Filter {

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		setCacheHeader((HttpServletResponse) response);
        chain.doFilter(request, response);
	}
	/**
	 * Sets the caching header directives (if enabled) on the given response
	 * @param response
	 */
	public void setCacheHeader(HttpServletResponse response) {
		if (cachingHeadersEnabled) 
			setCacheHeader(response,expirationTime);
			
	}
	/**
	 * Sets the caching header directives on the given response with the given expiration
	 * @param response
	 * @param expirationTime
	 */
	public static void setCacheHeader(HttpServletResponse response, long expirationTime) {
		response.setHeader("Pragma","");
        response.setHeader("Cache-Control","public");
        Date expirationDate = new Date(new Date().getTime() + expirationTime);
        DateFormat formatter = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss zzz");
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        response.setHeader("Expires",formatter.format(expirationDate));
	}
	/** 
	 * expiration time in the future to use for the caching directives
	 */
	long expirationTime = 86400000;
	/**
	 * indicates whether or not to use caching header directives
	 */
	boolean cachingHeadersEnabled = true;
	/**
	 * Read the configuration parameters
	 */
	public void init(FilterConfig config) throws ServletException {
	    if (config != null) {
	    	String expirationTimeParameter = config.getInitParameter("expiration-time"); 
	    	if (expirationTimeParameter != null) {
	    		this.expirationTime = Long.parseLong(expirationTimeParameter);
	    	}
	    	cachingHeadersEnabled = !"false".equals(config.getInitParameter("caching-headers-enabled"));
	    }
    }
}