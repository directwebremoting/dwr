/**
 *Resource Accelerate
Copyright (C) 2007 Xucia Incorporation
Author - Kris Zyp - kriszyp@xucia.com

The contents of this file are subject to the Mozilla Public License Version
1.1 (the "License"); you may not use this file except in compliance with
the License. You may obtain a copy of the License at
http://www.mozilla.org/MPL/

Software distributed under the License is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
for the specific language governing rights and limitations under the
License.
 */
package com.xucia.resourceaccelerate;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextAction;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.tools.ToolErrorReporter;
import org.mozilla.javascript.tools.shell.Global;
import org.mozilla.javascript.tools.shell.Main;
/**
 * 
 * @author Kris Zyp
 *This class applies Dojo ShrinkSafe to an output stream 
 */
public class JSShrinkOutputStream extends ByteArrayOutputStream {
	/**
	 * Must get the output stream to write to
	 * @param outputStream
	 */
	public JSShrinkOutputStream(OutputStream outputStream) {
		this.outputStream = outputStream;
	}
	OutputStream outputStream;
	/** 
	 * Do the compression when the stream closes
	 */
	@Override
	public void close() throws IOException {
		outputStream.write(shrinkJS(new String(toByteArray())).getBytes());
		outputStream.close();
	}
	/** 
	 * Perform the compression on the source as a string
	 * @param source
	 * @return
	 */
	static String shrinkJS(String source) {
		IProxy iproxy = new IProxy();
		iproxy.source = source;
		return (String) Main.shellContextFactory.call(iproxy);
	}
	static Global global = Main.getGlobal();
	static boolean initialized = false;
    private static class IProxy implements ContextAction
    {
		String[] args = new String[0];
		String source;
        IProxy()
        {
        }

        public Object run(Context cx)
        {
        	if (!initialized) {
        		initialized = true;
	    		ToolErrorReporter errorReporter = new ToolErrorReporter(false, global.getErr());
	    		Main.shellContextFactory.setErrorReporter(errorReporter);
	    		try {
	    				global.init(Main.shellContextFactory);
	    		}
	    		catch (Exception e) {
	    			System.err.println(e.getMessage());
	    		}
	
			}
			Script script = Main.loadScriptFromSource(cx, source, "compress", 1, null);
			return cx.compressReader(global, script, source, "compress", 1, null);        	
        }
    }
}
